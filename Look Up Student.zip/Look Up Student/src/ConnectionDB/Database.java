/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ConnectionDB;

import com.mysql.jdbc.Driver;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
/**
 *
 * @author Administrator
 */
public class Database {
     
     private static Connection ConnectionDB;
    
   public static Connection GetConnection()throws SQLException
   {
       if (ConnectionDB==null)
       {
           ConnectionDB=DriverManager.getConnection("jdbc:mysql://localhost:3306/lookupstudents","root","");
       }
       return ConnectionDB;
   }
 
    public static Object getConnection() {
        throw new UnsupportedOperationException("Not supported yet."); 
    }
}