/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package look.up.student;

/**
    * this is our first program, where the function
    * of this program is to input students data.
    * Design GUI UX 2018 with
    * The Admin User Login Function, Etc
    *
    * @Ramadhanfaa - PemalasTeam
    * @LookUpStudent V.1.0.0
 */
public class LookUpStudent {

    /**
     * 
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        formLogin A = new formLogin();
        A.setVisible(true);
        formRegister B = new formRegister();
        B.setVisible(false);
        dashboardMenu C = new dashboardMenu();
        C.setVisible(false);
    }
    
}
